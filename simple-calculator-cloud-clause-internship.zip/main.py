print("Press 1 for Addition")
print("Press 2 for Subtraction")
print("Press 3 for Multiplication")
print("Press 4 for Division")
a=input()

z="enter the numbers"
if a=="1":
    x=int(input(" how many numbers u are going to add: "))
    c=0
    print(z.upper())
    for i in range(x):
        b=int(input())
        c=b+c
    print("RESULT =",c)
elif a=="2":
    x=int(input(" How Many Numbers u are going to Subtract: "))
    c=0
    print(z.upper())
    for i in range(x):
        b=int(input())
        c=b-c
    print("RESULT =",c)
elif a=="3":
    x=int(input(" How Many Numbers u are going to Mul: "))
    c=1
    print(z.upper())
    for i in range(x):
        b=int(input())
        c*=b
    print("RESULT =",c)
elif a=="4":
    print("Div Should Perform only With two Numbers")
    print(z.upper())
    r=int(input())
    p=int(input())
    print("RESULT =",r/p)
else:
    print("LIMIT EXTENDED")